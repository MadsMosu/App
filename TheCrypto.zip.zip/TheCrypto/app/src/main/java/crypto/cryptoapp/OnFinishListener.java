package crypto.cryptoapp;

import java.util.List;

public interface OnFinishListener {
    public void onFinish(List<Asset> assets);
}
